-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Янв 31 2026 г., 17:31
-- Версия сервера: 8.0.30
-- Версия PHP: 8.0.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `it_shop`
--

CREATE DATABASE IF NOT EXISTS it_shop
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;
-- --------------------------------------------------------
USE it_shop;
--
-- Структура таблицы `products`
--

CREATE TABLE `products` (
  `id` int NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `category` varchar(50) COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'general',
  `description` text COLLATE utf8mb4_general_ci,
  `price` decimal(10,2) DEFAULT NULL,
  `image_path` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `full_description` text COLLATE utf8mb4_general_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Дамп данных таблицы `products`
--

INSERT INTO `products` (`id`, `name`, `category`, `description`, `price`, `image_path`, `full_description`) VALUES
(16, 'Razer Viper V3 Pro', 'mouse', 'Лёгкая беспроводная (54 г), Focus Pro 35K, до 95 ч работы', '1599.00', 'img/Razer Viper V3 Pro.jpg', 'Razer Viper V3 Pro — это ультралёгкая беспроводная мышь для киберспорта, весом всего 54 грамма, что делает её идеальной для быстрых и точных движений в FPS-играх. Она оснащена оптическим сенсором Focus Pro 35K с максимальной чувствительностью 35 000 DPI, скоростью отслеживания до 750 IPS и ускорением до 70 G. Мышь поддерживает беспроводную связь с задержкой менее 1 мс благодаря технологии Razer HyperSpeed Wireless, а батарея обеспечивает до 95 часов работы в режиме энергосбережения. Кнопки используют оптические переключатели Gen-3 с ресурсом 90 миллионов кликов, без двойных срабатываний. Эргономичная форма подходит для правшей, с хватом ладонью или когтем. Поверхность с матовым покрытием обеспечивает надёжный хват. Мышь совместима с Razer Synapse для настройки DPI, макросов и RGB-подсветки (хотя подсветка минимальна для экономии батареи). Идеально для профессиональных геймеров, стремящихся к максимальной скорости и точности, но может быть неудобной для левшей или любителей тяжёлых мышей.'),
(17, 'Logitech G Pro X Superlight 2', 'mouse', 'Сверхлёгкая 60 г, HERO 25K, LIGHTFORCE switches', '1400.00', 'img/Logitech G Pro X Superlight 2.jpg', 'Logitech G Pro X Superlight 2 — это сверхлёгкая беспроводная игровая мышь весом 60 граммов, разработанная для профессиональных киберспортсменов. Сенсор HERO 2 обеспечивает разрешение до 32 000 DPI, скорость отслеживания 500 IPS и ускорение 40 G. Мышь использует гибридные оптико-механические переключатели LIGHTFORCE с ресурсом 70 миллионов кликов, обеспечивая нулевую задержку и надёжность. Беспроводная связь LIGHTSPEED гарантирует задержку менее 1 мс, а батарея держит до 95 часов (зависит от режима). Эргономичная форма подходит для правшей с хватом ладонью или когтем. Мышь имеет минималистичный дизайн без RGB, чтобы минимизировать вес. Совместима с Logitech G HUB для настройки DPI, макросов и профилей. Отличный выбор для FPS-игр, где важна скорость, но может не подойти для пользователей, предпочитающих тяжёлые мыши или дополнительные кнопки.'),
(18, 'Razer DeathAdder V3 Pro', 'mouse', 'Эргономичная беспроводная FPS-мышь', '2999.00', 'img/Razer DeathAdder V3 Pro.jpg', 'Razer DeathAdder V3 Pro — эргономичная беспроводная мышь для FPS-игр, весом 63 грамма, с фокусом на комфорт и точность. Сенсор Focus Pro 30K предлагает до 30 000 DPI, скорость 750 IPS и ускорение 70 G. Оптические переключатели Gen-3 с ресурсом 90 миллионов кликов обеспечивают мгновенный отклик без двойных срабатываний. Беспроводная технология HyperSpeed Wireless с задержкой <1 мс и батареей до 90 часов. Эргономичная форма для правшей с хватом ладонью, покрытие для лучшего сцепления. Поддержка Razer Synapse для настройки DPI, макросов и RGB (минимальная подсветка). Идеальна для длительных игровых сессий в шутерах, но не подходит для левшей или тех, кто ищет симметричную мышь.'),
(19, 'Logitech G502 X Plus', 'mouse', 'RGB, 13 кнопок, LIGHTSYNC подсветка', '1999.00', 'img/Logitech G502 X Plus.jpg', 'Logitech G502 X Plus — многофункциональная беспроводная мышь с 13 программируемыми кнопками, весом 106 граммов, для универсального использования в играх и работе. Сенсор HERO 25K с 25 600 DPI, скоростью 400 IPS и ускорением 40 G. Гибридные переключатели LIGHTFORCE с ресурсом 70 миллионов кликов. LIGHTSYNC RGB-подсветка с 8 зонами. Беспроводная связь LIGHTSPEED с задержкой <1 мс, батарея до 130 часов (без RGB). Эргономичная форма для правшей. Совместима с G HUB для настройки. Подходит для MMO, MOBA и FPS, но вес может быть минусом для фанатов лёгких мышей.'),
(20, 'Corsair Katar Pro XT', 'mouse', 'Бюджетная симметричная лёгкая мышь', '3400.00', 'img/Corsair Katar Pro XT.jpg', 'Corsair Katar Pro XT — бюджетная симметричная игровая мышь весом 73 грамма, подходящая для правшей и левшей. Сенсор PMW3391 с 18 000 DPI, скоростью 300 IPS и ускорением 50 G. Переключатели Omron с ресурсом 50 миллионов кликов. 6 программируемых кнопок, RGB-подсветка на колесе. Кабель с парашютной оплёткой для минимального сопротивления. iCUE для настройки. Идеальна для начинающих геймеров в FPS, но без беспроводной связи и с базовыми функциями.'),
(21, 'NuPhy Field75HE', 'keyboard', 'Hall Effect 75%, регулируемая actuation, беспроводная', '8929.00', 'img/NuPhy Field75HE.jpg', 'NuPhy Field75 HE — 75% беспроводная механическая клавиатура с Hall Effect магнитными переключателями, регулируемой активацией от 0.1 до 4.0 мм. Поллинг-рейт 8000 Hz, задержка <0.5 мс. Беспроводная связь (Bluetooth, 2.4GHz), батарея 4000 мАч до 42 часов. Gasket-mount с силиконовой прокладкой для мягкого звука. PBT кейкапы, RGB-подсветка. Совместима с QMK/VIA для кастомизации. Идеальна для геймеров в FPS/MOBA, но требует настройки для оптимального опыта.'),
(22, 'Asus ROG Strix Scope II 96 Wireless', 'keyboard', 'Беспроводная механика 96%, отличный отклик', '9249.00', 'img/Asus ROG Strix Scope II 96 Wireless.jpg', 'Asus ROG Strix Scope II 96 Wireless — 96% беспроводная механическая клавиатура с ROG NX Snow переключателями, поллинг-рейт 1000 Hz. Три режима связи (Bluetooth, 2.4GHz, USB), батарея до 1500 часов. Gasket-mount, PBT кейкапы, силиконовая пена. RGB-подсветка, мультимедиа-колесо. Armoury Crate для кастомизации. Подходит для гейминга и тайпинга, но громоздкая для мобильности.'),
(23, 'Razer BlackWidow V4 Pro', 'keyboard', 'Механика + RGB + wrist rest', '2239.00', 'img/RazerBlackWidowV4 Pro.webp', 'Razer BlackWidow V4 Pro — полноразмерная механическая клавиатура с Razer Orange/Linear переключателями Gen-3, ресурсом 90 млн кликов. Поллинг 8000 Hz. RGB-подсветка, Command Dial, 8 макро-кнопок. Беспроводная (HyperSpeed), Bluetooth. PBT кейкапы, алюминиевый корпус. Synapse для настройки. Идеальна для геймеров и стримеров, но дорогая.'),
(24, 'SteelSeries Apex Pro TKL Gen 3', 'keyboard', 'OmniPoint регулируемые switches', '4500.00', 'img/SteelSeries Apex Pro TKL Gen 3.jpg', 'SteelSeries Apex Pro TKL Gen 3 — TKL механическая клавиатура с OmniPoint регулируемыми переключателями (0.1-4.0 мм). Поллинг 1000 Hz. OLED-дисплей, RGB-подсветка. PBT кейкапы, алюминиевый корпус. GG для настройки. Для FPS-геймеров, но требует привыкания к регулировке.'),
(25, 'Lemokey L3', 'keyboard', 'Бюджетная TKL механика', '9000.00', 'img/Lemokey L3.jpg', 'Lemokey L3 — TKL беспроводная механическая клавиатура с Gateron Jupiter переключателями. Поллинг 1000 Hz (2.4GHz). Gasket-mount, PC-плита. PBT кейкапы, RGB. QMK/VIA для кастомизации. Батарея 4000 мАч. Для гейминга и тайпинга, бюджетный вариант премиум-класса.'),
(26, 'Audeze Maxwell', 'headphones', 'Планарные драйверы, премиум звук + беспроводные', '15000.00', 'img/Audeze Maxwell.jpg', 'Audeze Maxwell — беспроводные наушники с планарными драйверами 90 мм, для премиум-звука в играх. Поддержка LDAC, aptX HD. Батарея 80+ часов. Беспроводная связь с низкой задержкой. Микрофон с AI-шумоподавлением. Комфортные амбушюры. EQ в приложении. Для аудиофилов-геймеров, но тяжёлые (490 г).'),
(27, 'SteelSeries Arctis Nova Pro Wireless', 'headphones', 'Dual wireless, сменные батареи', '9999.00', 'img/SteelSeries Arctis Nova Pro Wireless.jpg', 'SteelSeries Arctis Nova Pro Wireless — беспроводная гарнитура с dual-wireless (2.4GHz + Bluetooth), сменными батареями (до 22 часов каждая). Неодимовые драйверы 40 мм, ANC. Микрофон с шумоподавлением. База с EQ. Совместима с PC, консолями. Для геймеров, ищущих универсальность.'),
(28, 'Razer BlackShark V3 Pro', 'headphones', 'Беспроводные с топовым микрофоном', '8999.00', 'img/Razer BlackShark V3 Pro.jpg', 'Razer BlackShark V3 Pro — беспроводная гарнитура для FPS с 50 мм TriForce драйверами, ANC. Микрофон HyperClear. Батарея 70 часов. HyperSpeed Wireless. EQ в Synapse. Для соревновательного гейминга, но ANC средний.'),
(29, 'HyperX Cloud II', 'headphones', 'Классика комфорта и звука', '7990.00', 'img/HyperX Cloud II.jpg', 'HyperX Cloud II — классическая гарнитура с 53 мм драйверами, виртуальным 7.1 звуком. Памятная пена, съёмный микрофон. USB-саундкарта. Комфорт для длинных сессий. Для бюджетных геймеров, но без беспроводной связи.'),
(30, 'Logitech G Pro X 2 Lightspeed', 'headphones', 'Беспроводные с Blue VO!CE', '5990.00', 'img/Logitech G Pro X 2 Lightspeed.jpg', 'Logitech G Pro X 2 Lightspeed — беспроводная гарнитура с графеновыми драйверами 50 мм, Blue VO!CE микрофон. Батарея 50 часов. LIGHTSPEED + Bluetooth. EQ в G HUB. Для про-геймеров, фокус на комфорте и звуке.'),
(31, 'Elgato Key Light Neo', 'rgb_lighting', 'LED-панель с приложением, регулировка яркости/цвета', '1049.00', 'img/Elgato Key Light Neo.jpg', 'Elgato Key Light Neo — компактная LED-панель для освещения, яркость до 1000 люменов, температура 2900-7000K, CRI >94%. Wi-Fi/USB контроль. Крепление на монитор. Для стримеров/видеозвонков, но без RGB.'),
(32, 'Corsair iCUE LS100 Smart Strip', 'rgb_lighting', 'Адресуемые светодиодные полосы', '3700.00', 'img/Corsair iCUE LS100 Smart Strip.jpg', 'Corsair iCUE LS100 Smart Strip — адресуемые RGB-полосы (2x450мм + 2x250мм), 84 LED. iCUE для синхронизации. Для ПК/комнаты. Простая установка, но требует контроллера.'),
(33, 'Razer Chroma RGB Light Strip', 'rgb_lighting', 'Chroma-синхронизация', '5300.00', 'img/Razer Chroma RGB Light Strip.jpg', 'Razer Chroma RGB Light Strip — адресуемые RGB-полосы (1x100см + 2x50см), 120 LED. Synapse для синхронизации. Для геймерских сетапов, премиум свечение.'),
(34, 'Govee RGBIC LED Strip Gamings', 'rgb_lighting', 'С камерой, реакция на экран', '4000.00', 'img/GoveeRGBICLEDStripGamings.webp', 'Govee RGBIC LED Strip Gaming — RGBIC-полосы с камерой для реакции на экран. App-контроль, музыка-синх. Для иммерсивного гейминга, но установка сложная.'),
(35, 'Nanoleaf Essentials Lightstrip', 'rgb_lighting', 'Умная RGB-полоса', '3500.00', 'img/NanoleafEssentialsLightstrip.png', 'Nanoleaf Essentials Lightstrip — умная RGB-полоса (2м, расширяемая до 10м), 2200 люменов, 2700-6500K. Matter/Thread, App. Для акцентного освещения, интеграция в смарт-дом.'),
(36, 'Razer Kiyo Pro Ultra', 'webcam', '4K, отличная картинка в темноте, AI', '2000.00', 'img/Razer Kiyo Pro Ultra.webp', 'Razer Kiyo Pro Ultra — 4K-вебкамера с 1/1.2\" сенсором Sony STARVIS 2, f/1.7 объективом. Автофокус, HDR. Микрофон. Synapse для настройки. Для стримеров/контент-креаторов, премиум качество в темноте.'),
(37, 'Razer Kiyo Pro UltraaRazer Kiyo Pro Ultra', 'webcam', '1080p/60fps, высокое качество', '4300.00', 'img/Razer Kiyo Pro UltraaRazer Kiyo Pro Ultra.jpg', 'Elgato Facecam MK.2 — 1080p/60fps вебкамера с HDR, 84° FOV. Ручные настройки. Нет микрофона. Camera Hub. Для стримеров, но без 4K.'),
(38, 'Logitech Brio 500', 'webcam', '1080p с автофокусом и автоэкспозицией', '1009.00', 'img/Logitech Brio 500.webp', 'Logitech Brio 500 — 1080p вебкамера с автофреймингом, Show Mode. Двойные микрофоны. Logi Tune. Для видеозвонков, простой в использовании.'),
(39, 'Insta360 Link', 'webcam', '4K + AI-тримминг и gimbal', '1999.00', 'img/Insta360 Link.webp', 'Insta360 Link — 4K-вебкамера с гимбалом, AI-трекингом. 4x зум, HDR. Микрофоны. Для презентаций/стримов, но дорогая.'),
(40, 'Obsbot Tiny 3', 'webcam', '4K AI tracking, механический поворот', '2049.00', 'img/Obsbot Tiny 3.jpg', 'Obsbot Tiny 3 — компактная 4K-вебкамера с AI-трекингом, гимбалом. 1080p/120fps. Микрофоны. Для динамичных видео, но размер маленький.'),
(41, 'Corsair Vengeance i7600', 'gaming_pc', 'Топовый prebuilt 2026: Intel Core Ultra 9 + RTX 5090, 64 ГБ DDR5, отличное охлаждение и качество сборки', '40499.00', 'img/Corsair Vengeance i7600.webp', 'Corsair Vengeance i7600 — топовый prebuilt ПК с Intel Core Ultra 9, RTX 5090, 64 ГБ DDR5. 360mm AIO охлаждение. Для 4K-гейминга/рендера, премиум сборка.'),
(42, 'Asus ROG G700', 'gaming_pc', 'Мощный mid-range/high-end: AMD Ryzen 9 9950X3D + RTX 5080, RGB, хорошая расширяемость', '80999.00', 'img/Asus ROG G700.webp', 'Asus ROG G700 — mid/high-end ПК с AMD Ryzen 9 9950X3D, RTX 5080, 32 ГБ DDR5. RGB, расширяемость. Для гейминга/контента, баланс цены/производительности.'),
(43, 'Alienware Area-51 (2026)', 'gaming_pc', 'Премиум full-tower с упором на апгрейд: Intel i9 + RTX 5090, кастомный дизайн Alienware', '75000.00', 'img/Alienware Area-51 (2026).webp', 'Alienware Area-51 (2026) — премиум full-tower с Intel i9, RTX 5090, 64 ГБ DDR5. Кастом дизайн, апгрейд. Для энтузиастов, но дорогой.'),
(44, 'HP Omen 35L', 'gaming_pc', 'Лучший баланс цена/качество 2026: Ryzen 7 9800X3D + RTX 5070 Ti, тихий, легко апгрейдить', '60000.00', 'img/HP Omen 35L.webp', 'HP Omen 35L — балансный ПК с Ryzen 7 9800X3D, RTX 5070 Ti, 32 ГБ DDR5. Тихий, апгрейд. Для 1440p/4K гейминга.'),
(45, 'MSI Codex R2 / Aegis ZS2', 'gaming_pc', 'Доступный, но мощный вариант: Ryzen 7 + RTX 5070, отличный для 1440p/4K', '90099.00', 'img/MSI Codex R2Aegis ZS2.jpg', 'MSI Codex R2 / Aegis ZS2 — доступный ПК с Ryzen 7, RTX 5070, 32 ГБ DDR5. Для 1440p/4K, бюджетный high-end.');

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE `users` (
  `id` int NOT NULL,
  `first_name` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  `last_name` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  `username` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `avatar` varchar(255) COLLATE utf8mb4_general_ci DEFAULT 'default-avatar.png',
  `bio` text COLLATE utf8mb4_general_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `products`
--
ALTER TABLE `products`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=46;

--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
